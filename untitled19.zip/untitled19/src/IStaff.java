public interface IStaff {
    public int getStaffNumber();
    public String getStaffLocation();
    public String getStaffHiringProcess();
}
