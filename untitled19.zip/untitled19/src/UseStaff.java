import java.util.Scanner;
public class UseStaff {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the current staff number: ");
        int number = input.nextInt();
        input.nextLine(); // consume newline

        System.out.print("Enter the staff hiring location: ");
        String location = input.nextLine();

        StaffHiring staffHiring = new StaffHiring(number, location);
        staffHiring.printStaffHiring();

        input.close();
    }
}
